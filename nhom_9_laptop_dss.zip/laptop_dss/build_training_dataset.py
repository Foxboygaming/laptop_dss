#!/usr/bin/env python3
"""Tạo dữ liệu User × Laptop và nhãn suitability theo quy tắc minh bạch.
Chạy: python build_training_dataset.py --users user_profiles.csv --laptops laptop_dataset.csv
Nhãn là nhãn suy ra từ quy tắc, KHÔNG phải đánh giá thực tế của người dùng.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

U_REQUIRED = ["user_id","programming","gaming_need","multitasking_need","display_need",
              "battery_need","mobility_need","budget_max_million","budget_is_open_ended",
              "care_price","care_performance","care_gaming","care_battery",
              "care_portability","care_display","care_durability","preferred_brand"]
L_REQUIRED = ["ID","Laptop","Brand","Price (M)","Perf.","Gaming","Battery",
              "Portable","Display","Multi","Durability"]
L_RENAME = {"ID":"laptop_id","Laptop":"laptop_name","Brand":"laptop_brand",
            "Price (M)":"price_million","Perf.":"performance_level",
            "Gaming":"gaming_level","Battery":"battery_level",
            "Portable":"portability_level","Display":"display_level",
            "Multi":"multitasking_level","Durability":"durability_level"}

def need_fit(capacity, need):
    """1 nếu đáp ứng; giảm tuyến tính khi thiếu mức, không thưởng máy quá nhu cầu."""
    return np.clip(1 - np.maximum(need-capacity, 0)/4, 0, 1)

def build(users, laptops):
    missing_u = sorted(set(U_REQUIRED)-set(users.columns))
    missing_l = sorted(set(L_REQUIRED)-set(laptops.columns))
    if missing_u or missing_l:
        raise ValueError(f"Thiếu cột users: {missing_u}; laptops: {missing_l}")
    if users.user_id.isna().any() or users.user_id.duplicated().any():
        raise ValueError("user_id phải duy nhất và không rỗng")
    if laptops["ID"].isna().any() or laptops["ID"].duplicated().any():
        raise ValueError("ID laptop phải duy nhất và không rỗng")
    if (pd.to_numeric(laptops["Price (M)"],errors="coerce")<=0).any():
        raise ValueError("Giá laptop phải > 0")
    if users["budget_max_million"].isna().any():
        raise ValueError("Ngân sách người dùng bị thiếu: cần xử lý trước")

    # Giữ cột nguồn để có thể kiểm tra lại từng điểm.
    u = users.add_prefix("user_").rename(columns={"user_user_id":"user_id"})
    l = laptops.rename(columns=L_RENAME)
    # Chỉ lấy laptop features từ file laptop; không tạo cột duplicate mơ hồ.
    l = l.add_prefix("laptop_").rename(columns={"laptop_laptop_id":"laptop_id"})
    pairs = u.merge(l, how="cross", validate="many_to_many")

    # "Trên 40 triệu" là ngân sách mở: không được coi 40 là mức trần.
    budget = pd.to_numeric(pairs["user_budget_max_million"],errors="coerce")
    price = pd.to_numeric(pairs["laptop_price_million"],errors="coerce")
    open_ended = pairs["user_budget_is_open_ended"].fillna(0).astype(int).eq(1)
    budget_ok = open_ended | price.le(budget)
    pairs["within_budget"] = budget_ok.astype(int)
    pairs["over_budget_million"] = np.where(open_ended,0,np.maximum(price-budget,0))

    # 1–5: nhu cầu hiệu năng suy từ đa nhiệm và lập trình.
    perf_need = np.maximum(
        pd.to_numeric(pairs["user_multitasking_need"],errors="coerce").fillna(3),
        np.where(pairs["user_programming"].fillna(0).eq(1),3,1)
    )
    pairs["performance_need_derived"] = perf_need
    # gaming_need = 0 là không chơi, NaN là chưa rõ: không tự suy thành 0.
    gaming_need = pd.to_numeric(pairs["user_gaming_need"],errors="coerce")
    pairs["gaming_need_missing"] = gaming_need.isna().astype(int)

    criteria = [
        ("performance",perf_need,"laptop_performance_level","user_care_performance"),
        ("multitasking",pairs["user_multitasking_need"],"laptop_multitasking_level","user_care_performance"),
        ("gaming",gaming_need,"laptop_gaming_level","user_care_gaming"),
        ("battery",pairs["user_battery_need"],"laptop_battery_level","user_care_battery"),
        ("portability",pairs["user_mobility_need"],"laptop_portability_level","user_care_portability"),
        ("display",pairs["user_display_need"],"laptop_display_level","user_care_display"),
    ]
    weighted_sum = np.zeros(len(pairs),dtype=float)
    weight_total = np.zeros(len(pairs),dtype=float)
    for name, need, laptop_col, care_col in criteria:
        need = pd.to_numeric(need,errors="coerce")
        capacity = pd.to_numeric(pairs[laptop_col],errors="coerce")
        care = pd.to_numeric(pairs[care_col],errors="coerce").fillna(0)
        valid = need.notna() & capacity.notna() & need.gt(0)
        weight = np.where(valid,1+care,0)
        fit = need_fit(capacity,need.fillna(0))
        pairs[f"fit_{name}"] = np.where(valid,np.round(fit,3),np.nan)
        weighted_sum += weight*fit
        weight_total += weight

    # Độ bền chỉ có trọng số khi người dùng chọn quan tâm đến độ bền.
    durability_care = pairs["user_care_durability"].fillna(0).astype(float)
    dur_fit = need_fit(pd.to_numeric(pairs["laptop_durability_level"],errors="coerce"),4)
    weighted_sum += 2*durability_care*dur_fit
    weight_total += 2*durability_care

    # Giá: nếu vượt ngân sách, trừ điểm và đánh dấu để lọc khi khuyến nghị.
    # Máy trong ngân sách không mặc nhiên tốt hơn chỉ vì rẻ hơn.
    price_fit = np.where(budget_ok,1,np.clip(1-(price-budget)/budget,0,1))
    price_weight = 1+pairs["user_care_price"].fillna(0).astype(float)
    weighted_sum += price_fit*price_weight
    weight_total += price_weight
    pairs["fit_price"] = np.round(price_fit,3)

    # Thương hiệu: bonus nhỏ, không bắt buộc.
    brand = pairs["user_preferred_brand"].fillna("").str.strip().str.casefold()
    laptop_brand = pairs["laptop_laptop_brand"].fillna("").str.strip().str.casefold()
    known_brand = brand.isin(["asus","acer","apple","dell","hp","lenovo","msi"])
    pairs["brand_match"] = (known_brand & brand.eq(laptop_brand)).astype(int)
    score = 100*weighted_sum/np.maximum(weight_total,1)
    score += 3*pairs["brand_match"]
    # Laptop vượt ngân sách không đủ điều kiện khuyến nghị.
    # Vẫn giữ điểm gốc để phân tích, nhưng đặt điểm cuối cùng bằng 0.
    pairs["eligible_for_recommendation"] = budget_ok.astype(int)
    score = np.where(budget_ok, score, 0)
    pairs["suitability_score"] = np.round(np.clip(score,0,100),2)
    pairs["suitability_label"] = pd.cut(
        pairs["suitability_score"],
        bins=[-0.01,39.999,59.999,79.999,100],
        labels=["khong_phu_hop",
                "it_phu_hop",
                "phu_hop",
                "rat_phu_hop"]
    ).astype(str)
    return pairs

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--users",default="user_profiles.csv")
    p.add_argument("--laptops",default="laptop_dataset.csv")
    p.add_argument("--output",default="training_dataset.csv")
    args = p.parse_args()
    users = pd.read_csv(args.users)
    laptops = pd.read_csv(args.laptops)
    result = build(users,laptops)
    result.to_csv(args.output,index=False,encoding="utf-8-sig")
    print(f"Users={len(users)}; Laptops={len(laptops)}; Pairs={len(result)}")
    print(f"Saved: {Path(args.output).resolve()}")
    print("Labels:",result.suitability_label.value_counts().to_dict())
    print("Over-budget pairs:",int((result.within_budget==0).sum()))
    print("Missing gaming_need pairs:",int(result.gaming_need_missing.sum()))
    print("Lưu ý: nhãn sinh từ quy tắc, chưa phải nhãn đánh giá thực tế.")

if __name__=="__main__":
    main()
