"""
process_survey.py
=================

Chuyển dữ liệu khảo sát Google Forms về laptop thành User Profiles
cho project Laptop DSS + Decision Tree.

Input mặc định:
    data/raw/survey_responses.csv

Output:
    data/processed/user_profiles.csv
    data/processed/data_quality_report.csv

Cài thư viện:
    pip install pandas

Chạy:
    python process_survey.py

Lưu ý:
- File CSV gốc KHÔNG bị sửa.
- Script này dùng đúng 17 câu hỏi + Timestamp trong file khảo sát hiện tại.
- Các câu checkbox được tách thành các biến 0/1.
- Các mức nhu cầu được mã hóa theo thứ tự thấp -> cao.
- Các câu A/B được giữ nguyên dưới dạng raw để tránh tự ý giả định
  A hoặc B đại diện cho tiêu chí nào.
"""

from pathlib import Path
import re
import unicodedata
import pandas as pd


# ============================================================
# 1. CONFIG
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

# Nếu đặt script trong thư mục scripts/ của project:
# BASE_DIR sẽ là thư mục scripts, vì vậy đổi thành:
# BASE_DIR = Path(__file__).resolve().parent.parent
#
# Để script chạy đơn giản ngay cạnh CSV, mặc định dùng BASE_DIR.

INPUT_FILE = BASE_DIR / "survey_responses.csv"

# Nếu bạn dùng cấu trúc:
# laptop_dss/
#   data/raw/survey_responses.csv
#   scripts/process_survey.py
#
# hãy thay 2 dòng trên bằng:
# BASE_DIR = Path(__file__).resolve().parent.parent
# INPUT_FILE = BASE_DIR / "data" / "raw" / "survey_responses.csv"

OUTPUT_DIR = BASE_DIR / "processed"
OUTPUT_FILE = OUTPUT_DIR / "user_profiles.csv"
QUALITY_FILE = OUTPUT_DIR / "data_quality_report.csv"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. EXACT COLUMN NAMES FROM YOUR GOOGLE FORM
# ============================================================

COL = {
    "timestamp": "Timestamp",

    "purpose":
        "Bạn dự định sử dụng laptop cho những việc nào? ",

    "primary_purpose":
        "Trong những việc trên, hoạt động nào là quan trọng nhất đối với bạn?  ",

    "usage_hours":
        "Một ngày bình thường bạn sử dụng laptop khoảng bao lâu?",

    "environment":
        "Bạn thường sử dụng laptop ở đâu? ",

    "carry_frequency":
        "Bạn có thường xuyên phải mang laptop theo người không? ",

    "gaming":
        "Khi chơi game, bạn thường chơi loại game nào?  ",

    "multitasking":
        "Bạn thường làm những công việc nào cùng lúc trên laptop?  ",

    "display":
        "Bạn quan tâm đến chất lượng hình ảnh trên màn hình ở mức nào?  ",

    "video_usage":
        "Bạn thường sử dụng laptop để xem phim, video hoặc nội dung hình ảnh không?  ",

    "battery":
        "Bạn mong muốn laptop có thể sử dụng trong bao lâu mà không cần sạc?  ",

    "mobility_description":
        "Điều nào mô tả đúng nhất về cách bạn sử dụng laptop?  ",

    "budget":
        "Bạn dự định chi tối đa bao nhiêu cho laptop?  ",

    "brand":
        "  Bạn có ưu tiên thương hiệu laptop nào không?  ",

    "criteria":
        "Khi mua laptop, điều gì khiến bạn quan tâm nhất? ",

    "tradeoff_1":
        "Nếu phải lựa chọn, bạn thích phương án nào hơn?  ",

    "tradeoff_2":
        "Nếu phải lựa chọn ",

    "tradeoff_3":
        "Nếu phải lựa chọn .1",
}


# ============================================================
# 3. TEXT HELPERS
# ============================================================

def clean_text(value):
    """Chuẩn hóa khoảng trắng và xử lý NaN."""
    if pd.isna(value):
        return ""

    value = str(value)
    value = value.replace("\n", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def normalize_for_match(value):
    """
    Chuẩn hóa text để so sánh keyword.
    Bỏ dấu tiếng Việt, chuyển lowercase.
    """
    value = clean_text(value).lower()

    value = unicodedata.normalize("NFD", value)
    value = "".join(
        ch for ch in value
        if unicodedata.category(ch) != "Mn"
    )

    return value


def contains_any(value, keywords):
    """1 nếu câu trả lời chứa ít nhất một keyword."""
    text = normalize_for_match(value)

    return int(
        any(
            normalize_for_match(keyword) in text
            for keyword in keywords
        )
    )


def parse_checkbox(value):
    """
    Google Forms lưu checkbox thành:
        'Học tập, Lập trình, Chơi game'

    Hàm trả về list lựa chọn.
    """
    value = clean_text(value)

    if not value:
        return []

    return [
        item.strip()
        for item in value.split(",")
        if item.strip()
    ]


# ============================================================
# 4. LOAD CSV
# ============================================================

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"\nKhông tìm thấy file CSV:\n{INPUT_FILE}\n\n"
        "Hãy đặt file Google Forms vào cùng thư mục với "
        "process_survey.py và đặt tên là survey_responses.csv."
    )

df = pd.read_csv(INPUT_FILE)

print("=" * 70)
print("LAPTOP DSS - PROCESS SURVEY")
print("=" * 70)

print(f"\nInput: {INPUT_FILE}")
print(f"Số phản hồi: {len(df)}")
print(f"Số cột: {len(df.columns)}")


# ============================================================
# 5. VERIFY COLUMNS
# ============================================================

missing_columns = [
    column
    for column in COL.values()
    if column not in df.columns
]

if missing_columns:
    print("\nCác cột không tìm thấy:")
    for column in missing_columns:
        print(f"  - {repr(column)}")

    print("\nCác cột thực tế trong file:")
    for i, column in enumerate(df.columns, start=1):
        print(f"  {i:02d}. {repr(column)}")

    raise ValueError(
        "\nTên cột trong CSV không khớp với Google Form hiện tại."
    )


# ============================================================
# 6. CLEAN RAW TEXT
# ============================================================

for column in df.columns:
    if df[column].dtype == "object":
        df[column] = df[column].apply(clean_text)


# ============================================================
# 7. INITIAL USER PROFILE
# ============================================================

profile = pd.DataFrame(index=df.index)

profile["user_id"] = [
    f"U{i:03d}"
    for i in range(1, len(df) + 1)
]

# Giữ timestamp để truy vết, nhưng KHÔNG dùng làm feature ML.
profile["timestamp"] = df[COL["timestamp"]]


# ============================================================
# 8. PURPOSE FEATURES
# ============================================================

purpose = df[COL["purpose"]]

profile["study"] = purpose.apply(
    lambda x: contains_any(x, ["Học tập"])
)

profile["office"] = purpose.apply(
    lambda x: contains_any(x, ["Làm việc văn phòng"])
)

profile["programming"] = purpose.apply(
    lambda x: contains_any(x, ["Lập trình"])
)

profile["gaming"] = purpose.apply(
    lambda x: contains_any(x, ["Chơi game"])
)

profile["entertainment"] = purpose.apply(
    lambda x: contains_any(x, ["Xem phim / YouTube"])
)

profile["photo_editing"] = purpose.apply(
    lambda x: contains_any(x, ["Chỉnh sửa ảnh"])
)

profile["video_editing"] = purpose.apply(
    lambda x: contains_any(x, ["Chỉnh sửa video"])
)

profile["design"] = purpose.apply(
    lambda x: contains_any(x, ["Vẽ / thiết kế"])
)

profile["online_meeting"] = purpose.apply(
    lambda x: contains_any(x, ["Họp trực tuyến"])
)

profile["social_media"] = purpose.apply(
    lambda x: contains_any(x, ["Sử dụng mạng xã hội"])
)


# ============================================================
# 9. PRIMARY PURPOSE
# ============================================================

profile["primary_purpose"] = df[COL["primary_purpose"]]


# ============================================================
# 10. DAILY USAGE
# ============================================================

usage_map = {
    "Dưới 2 giờ": 1,
    "2–4 giờ": 2,
    "2-4 giờ": 2,
    "4–6 giờ": 3,
    "4-6 giờ": 3,
    "6–8 giờ": 4,
    "6-8 giờ": 4,
    "Trên 8 giờ": 5,
}

profile["usage_level"] = (
    df[COL["usage_hours"]]
    .map(usage_map)
)

# Mức giữa khoảng thời gian, dùng cho phân tích nếu cần.
profile["usage_hours_midpoint"] = (
    df[COL["usage_hours"]]
    .map({
        "Dưới 2 giờ": 1,
        "2–4 giờ": 3,
        "2-4 giờ": 3,
        "4–6 giờ": 5,
        "4-6 giờ": 5,
        "6–8 giờ": 7,
        "6-8 giờ": 7,
        "Trên 8 giờ": 9,
    })
)


# ============================================================
# 11. ENVIRONMENT
# ============================================================

environment = df[COL["environment"]]

profile["uses_home"] = environment.apply(
    lambda x: contains_any(x, ["Chủ yếu ở nhà"])
)

profile["uses_school"] = environment.apply(
    lambda x: contains_any(x, ["Ở trường"])
)

profile["uses_office"] = environment.apply(
    lambda x: contains_any(x, ["Ở văn phòng"])
)

profile["uses_cafe"] = environment.apply(
    lambda x: contains_any(x, ["Quán cà phê"])
)


# ============================================================
# 12. CARRY FREQUENCY / MOBILITY
# ============================================================

carry_map = {
    "Hầu như không": 1,
    "Thỉnh thoảng": 2,
    "Vài lần mỗi tuần": 3,
    "Gần như mỗi ngày": 4,
}

profile["carry_frequency_level"] = (
    df[COL["carry_frequency"]]
    .map(carry_map)
)

mobility_description = df[COL["mobility_description"]]

profile["mobility_need"] = mobility_description.map({
    "Tôi gần như không mang laptop đi đâu": 1,
    "Tôi thỉnh thoảng mang theo": 2,
    "Tôi mang laptop đi học / đi làm thường xuyên": 3,
    "Tôi thường xuyên di chuyển và muốn laptop càng nhẹ càng tốt": 4,
})


# ============================================================
# 13. GAMING
# ============================================================

gaming = df[COL["gaming"]]

# Các biến 0/1 giúp giữ thông tin chi tiết.
profile["plays_light_games"] = gaming.apply(
    lambda x: contains_any(
        x, ["Game nhẹ / game online đơn giản"]
    )
)

profile["plays_esports"] = gaming.apply(
    lambda x: contains_any(
        x, ["Game eSports như Valorant, LoL, CS2"]
    )
)

profile["plays_3d"] = gaming.apply(
    lambda x: contains_any(
        x, ["Game 3D phổ biến"]
    )
)

profile["plays_aaa"] = gaming.apply(
    lambda x: contains_any(
        x, ["Game AAA / đồ họa cao"]
    )
)

# Nếu người dùng không trả lời gaming -> giữ NaN.
# Không tự động coi missing là "không chơi game".
def calculate_gaming_need(value):
    text = normalize_for_match(value)

    if not text:
        return pd.NA

    if "toi khong choi game" in text:
        return 0

    # Lấy mức cao nhất nếu chọn nhiều loại.
    if "game aaa" in text:
        return 4

    if "game 3d" in text:
        return 3

    if "esports" in text:
        return 2

    if "game nhe" in text:
        return 1

    return pd.NA


profile["gaming_need"] = gaming.apply(
    calculate_gaming_need
)


# ============================================================
# 14. MULTITASKING
# ============================================================

multitasking_map = {
    "Chỉ một ứng dụng tại một thời điểm": 1,
    "Trình duyệt + Word/Excel": 2,
    "Nhiều tab trình duyệt + nhiều ứng dụng": 3,
    "IDE (VSCode, PyCharm, vv) + trình duyệt + nhiều ứng dụng": 4,
    "Chỉnh sửa video / đồ họa + các ứng dụng khác": 5,
}

profile["multitasking_need"] = (
    df[COL["multitasking"]]
    .map(multitasking_map)
)


# ============================================================
# 15. DISPLAY
# ============================================================

display_map = {
    "Không quá quan trọng": 1,
    "Chỉ cần hình ảnh rõ ràng": 2,
    "Muốn hình ảnh đẹp, màu sắc tốt": 3,
    "Rất quan tâm đến màu sắc và chất lượng hiển thị": 4,
}

profile["display_need"] = (
    df[COL["display"]]
    .map(display_map)
)


# ============================================================
# 16. VIDEO / ENTERTAINMENT
# ============================================================

video_map = {
    "Hầu như không": 1,
    "Thỉnh thoảng": 2,
    "Thường xuyên": 3,
    "Rất thường xuyên": 4,
}

profile["entertainment_need"] = (
    df[COL["video_usage"]]
    .map(video_map)
)


# ============================================================
# 17. BATTERY
# ============================================================

battery = df[COL["battery"]]

profile["battery_need"] = battery.map({
    "Khoảng 2–3 giờ là đủ": 1,
    "Tôi thường xuyên sử dụng gần ổ điện": 2,
    "Khoảng 4–5 giờ": 3,
    "Khoảng 6–7 giờ": 4,
    "8 giờ trở lên": 5,
})

# Giữ riêng thông tin "gần ổ điện", vì nó không thực sự
# cùng một thang đo với số giờ.
profile["usually_near_power"] = (
    battery == "Tôi thường xuyên sử dụng gần ổ điện"
).astype(int)


# ============================================================
# 18. BUDGET
# ============================================================

budget = df[COL["budget"]]


def extract_numbers(text):
    text = clean_text(text)

    values = re.findall(
        r"\d+(?:[.,]\d+)?",
        text
    )

    return [
        float(value.replace(",", "."))
        for value in values
    ]


def budget_min(text):
    numbers = extract_numbers(text)

    if not numbers:
        return pd.NA

    return min(numbers)


def budget_max(text):
    numbers = extract_numbers(text)

    if not numbers:
        return pd.NA

    return max(numbers)


profile["budget_min_million"] = budget.apply(budget_min)
profile["budget_max_million"] = budget.apply(budget_max)

# Với "Trên 40 triệu", 40 được hiểu là ngưỡng tối thiểu.
# Không coi 40 là ngân sách tối đa thực tế.
profile["budget_is_open_ended"] = (
    budget.str.contains(
        "Trên 40 triệu",
        na=False
    )
).astype(int)

# Budget dùng để kiểm tra laptop có vượt ngân sách hay không.
# Đối với "Trên 40 triệu", tạm thời dùng 40 như lower bound,
# và đánh dấu open-ended để xử lý riêng ở bước suitability.


# ============================================================
# 19. BRAND PREFERENCE
# ============================================================

profile["preferred_brand"] = df[COL["brand"]]

profile["has_brand_preference"] = (
    ~df[COL["brand"]]
    .fillna("")
    .str.strip()
    .isin(["", "Chưa biết"])
).astype(int)


# ============================================================
# 20. BUYING CRITERIA
# ============================================================

criteria = df[COL["criteria"]]

profile["care_price"] = criteria.apply(
    lambda x: contains_any(x, ["Giá hợp lý"])
)

profile["care_performance"] = criteria.apply(
    lambda x: contains_any(x, ["Máy chạy nhanh"])
)

profile["care_gaming"] = criteria.apply(
    lambda x: contains_any(x, ["Chơi game tốt"])
)

profile["care_battery"] = criteria.apply(
    lambda x: contains_any(x, ["Pin lâu"])
)

profile["care_portability"] = criteria.apply(
    lambda x: contains_any(x, ["Nhẹ, dễ mang theo"])
)

profile["care_display"] = criteria.apply(
    lambda x: contains_any(x, ["Màn hình đẹp"])
)

profile["care_durability"] = criteria.apply(
    lambda x: contains_any(x, ["Máy bền"])
)

profile["care_design"] = criteria.apply(
    lambda x: contains_any(x, ["Thiết kế đẹp"])
)

profile["care_brand"] = criteria.apply(
    lambda x: contains_any(x, ["Thương hiệu uy tín"])
)

profile["care_storage"] = criteria.apply(
    lambda x: contains_any(x, ["Nhiều dung lượng lưu trữ"])
)


# ============================================================
# 21. TRADE-OFFS
# ============================================================
#
# CHƯA tự gán A/B thành "performance", "portability", v.v.
# vì CSV chỉ chứa A/B, còn ý nghĩa A/B nằm ở nội dung option
# trong Google Form.
#
# Ta giữ cả raw answer và numeric encoding:
# A = 0
# B = 1
# Không chắc / Không có sự khác = NaN
#
# Sau khi xác nhận nội dung A/B, có thể tạo thêm các feature
# semantic như:
#     prefers_performance_over_portability
#     prefers_performance_over_price
#     prefers_battery_over_performance
#
# ============================================================

def encode_ab(value):
    value = clean_text(value).lower()

    if value == "a":
        return 0

    if value == "b":
        return 1

    return pd.NA


profile["tradeoff_1_raw"] = df[COL["tradeoff_1"]]
profile["tradeoff_2_raw"] = df[COL["tradeoff_2"]]
profile["tradeoff_3_raw"] = df[COL["tradeoff_3"]]

profile["tradeoff_1_ab"] = df[COL["tradeoff_1"]].apply(encode_ab)
profile["tradeoff_2_ab"] = df[COL["tradeoff_2"]].apply(encode_ab)
profile["tradeoff_3_ab"] = df[COL["tradeoff_3"]].apply(encode_ab)


# ============================================================
# 22. DATA QUALITY FLAGS
# ============================================================

profile["missing_gaming"] = (
    df[COL["gaming"]].fillna("").str.strip() == ""
).astype(int)

profile["missing_criteria"] = (
    df[COL["criteria"]].fillna("").str.strip() == ""
).astype(int)

profile["missing_tradeoff_1"] = (
    df[COL["tradeoff_1"]].fillna("").str.strip() == ""
).astype(int)

profile["missing_tradeoff_2"] = (
    df[COL["tradeoff_2"]].fillna("").str.strip() == ""
).astype(int)

profile["missing_tradeoff_3"] = (
    df[COL["tradeoff_3"]].fillna("").str.strip() == ""
).astype(int)


# ============================================================
# 23. DATA TYPES
# ============================================================

numeric_columns = [
    column
    for column in profile.columns
    if column not in [
        "user_id",
        "timestamp",
        "primary_purpose",
        "preferred_brand",
        "tradeoff_1_raw",
        "tradeoff_2_raw",
        "tradeoff_3_raw",
    ]
]

for column in numeric_columns:
    profile[column] = pd.to_numeric(
        profile[column],
        errors="coerce"
    )


# ============================================================
# 24. QUALITY REPORT
# ============================================================

quality_rows = []

for column in profile.columns:
    missing = int(profile[column].isna().sum())

    quality_rows.append({
        "column": column,
        "dtype": str(profile[column].dtype),
        "rows": len(profile),
        "missing": missing,
        "missing_percent": round(
            missing / len(profile) * 100,
            2
        ),
        "unique_values": int(
            profile[column].nunique(dropna=True)
        ),
    })

quality = pd.DataFrame(quality_rows)

quality.to_csv(
    QUALITY_FILE,
    index=False,
    encoding="utf-8-sig"
)


# ============================================================
# 25. SAVE USER PROFILES
# ============================================================

profile.to_csv(
    OUTPUT_FILE,
    index=False,
    encoding="utf-8-sig"
)


# ============================================================
# 26. CONSOLE SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("PROCESSING COMPLETED")
print("=" * 70)

print(f"\nUser Profiles:")
print(f"  Rows    : {profile.shape[0]}")
print(f"  Columns : {profile.shape[1]}")

print(f"\nOutput:")
print(f"  {OUTPUT_FILE}")
print(f"  {QUALITY_FILE}")

print("\nMissing values:")
missing_summary = profile.isna().sum()
missing_summary = missing_summary[missing_summary > 0]

if len(missing_summary) == 0:
    print("  Không có missing value.")
else:
    for column, count in missing_summary.items():
        print(
            f"  {column}: "
            f"{count} "
            f"({count / len(profile) * 100:.1f}%)"
        )

print("\nPreview:")
print(profile.head(5).to_string(index=False))

print("\nHoàn tất.")
