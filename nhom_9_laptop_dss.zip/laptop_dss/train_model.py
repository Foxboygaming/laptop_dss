#!/usr/bin/env python3
"""Huấn luyện DecisionTreeRegressor từ training_dataset.csv.

Chạy: python train_model.py --data training_dataset.csv
Cài thư viện: python -m pip install pandas numpy scikit-learn joblib

Chỉ train trên các cặp nằm trong ngân sách; khi triển khai, PHẢI lọc ngân sách
trước khi dự đoán/xếp hạng. Điểm mục tiêu được tạo bởi quy tắc, không phải
đánh giá mua hàng thực tế. Không đưa các cột fit_*, nhãn hoặc điểm vào X.
"""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeRegressor, export_text

NUMERIC_FEATURES = [
    "user_programming", "user_gaming_need", "user_multitasking_need",
    "user_display_need", "user_battery_need", "user_mobility_need",
    "user_budget_max_million", "user_budget_is_open_ended",
    "user_care_price", "user_care_performance", "user_care_gaming",
    "user_care_battery", "user_care_portability", "user_care_display",
    "user_care_durability", "laptop_price_million",
    "laptop_performance_level", "laptop_gaming_level",
    "laptop_battery_level", "laptop_portability_level",
    "laptop_display_level", "laptop_multitasking_level",
    "laptop_durability_level",
]
CATEGORICAL_FEATURES = ["user_preferred_brand", "laptop_laptop_brand"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def main():
    parser = argparse.ArgumentParser(description="Train cây quyết định dự đoán điểm phù hợp")
    parser.add_argument("--data", default="training_dataset.csv")
    parser.add_argument("--outdir", default="models")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--max-depth", type=int, default=7)
    args = parser.parse_args()
    if not 0 < args.test_size < 1:
        parser.error("--test-size phải nằm giữa 0 và 1")
    df = pd.read_csv(args.data)
    required = set(FEATURES + ["user_id", "laptop_id", "within_budget", "suitability_score"])
    missing = sorted(required - set(df.columns))
    if missing:
        parser.error(f"File thiếu cột: {missing}. Hãy chạy lại build_training_dataset.py")
    if df["user_id"].isna().any():
        parser.error("user_id có giá trị thiếu")
    if df.duplicated(["user_id", "laptop_id"]).any():
        parser.error("Có cặp user_id/laptop_id bị trùng")

    # Không học nhãn 0 do vượt ngân sách: đó là quy tắc lọc, không phải
    # tín hiệu về chất lượng phần cứng. Không lấy within_budget làm feature.
    eligible = df.loc[df["within_budget"].eq(1)].copy()
    eligible["suitability_score"] = pd.to_numeric(
        eligible["suitability_score"], errors="coerce"
    )
    eligible = eligible.dropna(subset=["suitability_score"])
    if eligible["user_id"].nunique() < 5:
        parser.error("Cần ít nhất 5 người dùng có laptop trong ngân sách để chia tập")

    X = eligible[FEATURES].copy()
    for col in NUMERIC_FEATURES:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    for col in CATEGORICAL_FEATURES:
        X[col] = X[col].astype("string").fillna("khong_ro").astype(str)
    y = eligible["suitability_score"]

    splitter = GroupShuffleSplit(n_splits=1, test_size=args.test_size, random_state=42)
    train_idx, test_idx = next(splitter.split(X, y, groups=eligible["user_id"]))
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    train_users = set(eligible.iloc[train_idx]["user_id"])
    test_users = set(eligible.iloc[test_idx]["user_id"])
    assert not (train_users & test_users), "Rò rỉ user_id giữa train và test"

    preprocessor = ColumnTransformer([
        ("num", SimpleImputer(strategy="median"), NUMERIC_FEATURES),
        ("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), CATEGORICAL_FEATURES),
    ])
    model = Pipeline([
        ("preprocess", preprocessor),
        ("tree", DecisionTreeRegressor(
            max_depth=args.max_depth, min_samples_leaf=8, random_state=42
        )),
    ])
    model.fit(X_train, y_train)
    predictions = np.clip(model.predict(X_test), 0, 100)
    baseline = np.full(len(y_test), float(y_train.mean()))
    metrics = {
        "target_note": "Độ khớp với điểm do công thức tạo, KHÔNG phải độ chính xác sở thích mua laptop thực tế.",
        "training_scope": "Chỉ các cặp trong ngân sách; luôn lọc ngân sách trước khi khuyến nghị.",
        "total_pairs": int(len(df)),
        "eligible_pairs": int(len(eligible)),
        "train_pairs": int(len(train_idx)),
        "test_pairs": int(len(test_idx)),
        "train_users": len(train_users),
        "test_users": len(test_users),
        "user_overlap": len(train_users & test_users),
        "mae": round(float(mean_absolute_error(y_test, predictions)), 3),
        "rmse": round(float(np.sqrt(mean_squared_error(y_test, predictions))), 3),
        "r2": round(float(r2_score(y_test, predictions)), 3),
        "baseline_mae": round(float(mean_absolute_error(y_test, baseline)), 3),
        "tree_depth": int(model.named_steps["tree"].get_depth()),
        "tree_leaves": int(model.named_steps["tree"].get_n_leaves()),
        "features": FEATURES,
    }
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, out / "decision_tree_regressor.joblib")
    (out / "metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    names = model.named_steps["preprocess"].get_feature_names_out()
    (out / "decision_tree_rules.txt").write_text(
        export_text(model.named_steps["tree"], feature_names=list(names), max_depth=5),
        encoding="utf-8",
    )
    preview = eligible.iloc[test_idx][["user_id", "laptop_id", "suitability_score"]].copy()
    preview["predicted_score"] = np.round(predictions, 2)
    preview["absolute_error"] = np.round(np.abs(y_test.to_numpy() - predictions), 2)
    preview.to_csv(out / "test_predictions.csv", index=False, encoding="utf-8-sig")
    print("Đã train DecisionTreeRegressor và lưu trong:", out.resolve())
    for key in ["total_pairs", "eligible_pairs", "train_pairs", "test_pairs",
                "train_users", "test_users", "user_overlap", "mae", "rmse",
                "r2", "baseline_mae", "tree_depth", "tree_leaves"]:
        print(f"{key}: {metrics[key]}")
    print("Lưu ý:", metrics["target_note"])


if __name__ == "__main__":
    main()
