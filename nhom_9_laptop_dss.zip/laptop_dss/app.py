"""Giao diện DSS laptop. Chạy: streamlit run app.py"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from train_model import FEATURES, NUMERIC_FEATURES, CATEGORICAL_FEATURES

BASE = Path(__file__).resolve().parent
MODEL_PATH = BASE / 'models' / 'decision_tree_regressor.joblib'
LAPTOP_PATH = BASE / 'laptop_dataset.csv'
RENAME = {
    'ID': 'laptop_id', 'Laptop': 'laptop_name', 'Brand': 'laptop_brand',
    'Price (M)': 'price_million', 'Perf.': 'performance_level',
    'Gaming': 'gaming_level', 'Battery': 'battery_level',
    'Portable': 'portability_level', 'Display': 'display_level',
    'Multi': 'multitasking_level', 'Durability': 'durability_level',
}

def load_assets():
    if not MODEL_PATH.is_file():
        st.error(f'Chưa có mô hình: {MODEL_PATH}. Hãy chạy train_model.py trước.')
        st.stop()
    if not LAPTOP_PATH.is_file():
        st.error(f'Chưa có file laptop: {LAPTOP_PATH}')
        st.stop()
    try:
        model = joblib.load(MODEL_PATH)  # Chỉ tải mô hình do chính bạn tạo, không tải file joblib lạ.
        laptops = pd.read_csv(LAPTOP_PATH).rename(columns=RENAME)
    except Exception as exc:
        st.error(f'Không đọc được mô hình hoặc dữ liệu: {exc}')
        st.stop()
    required = set(RENAME.values())
    missing = sorted(required - set(laptops.columns))
    if missing:
        st.error(f'Laptop Dataset thiếu cột: {missing}')
        st.stop()
    laptops['price_million'] = pd.to_numeric(laptops['price_million'], errors='coerce')
    laptops = laptops.dropna(subset=['price_million']).copy()
    return model, laptops

st.set_page_config(page_title='Laptop DSS', page_icon='💻', layout='wide')
st.title('💻 Hệ hỗ trợ quyết định lựa chọn laptop')
st.caption('Dự đoán điểm phù hợp bằng cây quyết định; ngân sách là điều kiện lọc bắt buộc.')
model, laptops = load_assets()

with st.sidebar:
    st.header('Nhu cầu của bạn')
    budget_open = st.checkbox('Không giới hạn ngân sách tối đa', value=False)
    budget = st.number_input('Ngân sách tối đa (triệu VNĐ)', min_value=1.0,
                             max_value=1000.0, value=25.0, step=1.0,
                             disabled=budget_open)
    programming = st.checkbox('Có nhu cầu lập trình', value=False)
    gaming = st.slider('Nhu cầu chơi game (0 = không chơi)', 0, 5, 2)
    multi = st.slider('Nhu cầu đa nhiệm', 1, 5, 3)
    display = st.slider('Nhu cầu màn hình', 1, 5, 3)
    battery = st.slider('Nhu cầu pin', 1, 5, 3)
    mobility = st.slider('Nhu cầu di chuyển', 1, 5, 3)
    brand_options = ['Chưa biết'] + sorted(laptops['laptop_brand'].dropna().astype(str).unique().tolist())
    brand = st.selectbox('Thương hiệu ưu tiên', brand_options)
    st.subheader('Các tiêu chí bạn đặc biệt quan tâm')
    care_price = st.checkbox('Giá', value=True)
    care_perf = st.checkbox('Hiệu năng', value=True)
    care_gaming = st.checkbox('Gaming', value=False)
    care_battery = st.checkbox('Pin', value=False)
    care_portability = st.checkbox('Di động', value=False)
    care_display = st.checkbox('Màn hình', value=False)
    care_durability = st.checkbox('Độ bền', value=False)

user = {
    'user_programming': int(programming),
    'user_gaming_need': gaming,
    'user_multitasking_need': multi,
    'user_display_need': display,
    'user_battery_need': battery,
    'user_mobility_need': mobility,
    'user_budget_max_million': float(budget),
    'user_budget_is_open_ended': int(budget_open),
    'user_care_price': int(care_price),
    'user_care_performance': int(care_perf),
    'user_care_gaming': int(care_gaming),
    'user_care_battery': int(care_battery),
    'user_care_portability': int(care_portability),
    'user_care_display': int(care_display),
    'user_care_durability': int(care_durability),
    'user_preferred_brand': brand,
}

eligible = laptops.copy() if budget_open else laptops.loc[laptops['price_million'] <= budget].copy()
st.write(f'**{len(eligible)} / {len(laptops)} laptop** đáp ứng điều kiện ngân sách.')
if eligible.empty:
    st.warning('Không có laptop nào trong ngân sách này. Hãy tăng ngân sách hoặc thay đổi danh mục laptop.')
    st.stop()

# Dùng đúng cột và kiểu dữ liệu của pipeline lúc huấn luyện.
X = pd.DataFrame([{**user, **{
    'laptop_' + col: row[col] for col in [
        'price_million', 'performance_level', 'gaming_level', 'battery_level',
        'portability_level', 'display_level', 'multitasking_level',
        'durability_level', 'laptop_brand'
    ]
}} for _, row in eligible.iterrows()])
# laptop_laptop_brand là tên cột được tạo khi ghép dữ liệu trong build_training_dataset.py.
for col in NUMERIC_FEATURES:
    X[col] = pd.to_numeric(X[col], errors='coerce')
for col in CATEGORICAL_FEATURES:
    X[col] = X[col].astype('string').fillna('khong_ro').astype(str)
try:
    eligible['predicted_score'] = np.clip(model.predict(X[FEATURES]), 0, 100)
except Exception as exc:
    st.error(f'Lỗi dự đoán: {exc}. Kiểm tra model và file train_model.py có cùng phiên bản.')
    st.stop()

eligible = eligible.sort_values(['predicted_score', 'price_million'], ascending=[False, True])

def explain(row):
    reasons = []
    needs = [
        ('gaming_level', gaming, 'gaming'),
        ('performance_level', max(multi, 3 if programming else 1), 'hiệu năng'),
        ('battery_level', battery, 'pin'),
        ('portability_level', mobility, 'di động'),
        ('display_level', display, 'màn hình'),
        ('multitasking_level', multi, 'đa nhiệm'),
    ]
    for col, need, name in needs:
        if need > 0 and pd.notna(row[col]):
            reasons.append(f'{name}: {"đáp ứng" if row[col] >= need else "thấp hơn"} nhu cầu ({row[col]}/5 so với {need}/5)')
    return '; '.join(reasons)

st.subheader('Top 3 laptop được đề xuất')
for i, (_, laptop) in enumerate(eligible.head(3).iterrows(), start=1):
    with st.container(border=True):
        st.markdown(f'### {i}. {laptop["laptop_name"]}')
        c1, c2, c3 = st.columns(3)
        c1.metric('Giá (triệu VNĐ)', f'{laptop["price_million"]:,.1f}')
        c2.metric('Điểm dự đoán / 100', f'{laptop["predicted_score"]:.1f}')
        c3.metric('Thương hiệu', str(laptop['laptop_brand']))
        st.write('**Đối chiếu nhu cầu:** ' + explain(laptop))
        st.caption('Các nhận xét về từng tiêu chí là so sánh mức 1–5 trong dataset, không phải lời giải thích nhân quả của mô hình.')

with st.expander('Xem toàn bộ laptop trong ngân sách'):
    cols = ['laptop_id', 'laptop_name', 'laptop_brand', 'price_million', 'predicted_score',
            'performance_level', 'gaming_level', 'battery_level', 'portability_level',
            'display_level', 'multitasking_level', 'durability_level']
    st.dataframe(eligible[cols].rename(columns={
        'laptop_name': 'Laptop', 'laptop_brand': 'Hãng',
        'price_million': 'Giá (triệu)', 'predicted_score': 'Điểm dự đoán'
    }), use_container_width=True, hide_index=True)

st.info('Điểm dự đoán phản ánh mức độ khớp với công thức chấm điểm đã dùng tạo dữ liệu huấn luyện, chưa phải đánh giá mức hài lòng thực tế của người mua.')
