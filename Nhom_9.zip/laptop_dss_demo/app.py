import streamlit as st
import pandas as pd
import numpy as np
from ahp import ahp_weights
from topsis import topsis

st.set_page_config(page_title="Laptop DSS", page_icon="💻", layout="wide")

# -----------------------------
# Sample database
# -----------------------------
data = [
    ["ASUS TUF Gaming A15", "ASUS", 23990000, 8, 4060, 16, 512, 15.6, 144, 2.30, 90],
    ["Lenovo LOQ 15", "Lenovo", 24990000, 7, 4060, 16, 512, 15.6, 144, 2.38, 60],
    ["Acer Nitro V 15", "Acer", 21990000, 7, 4050, 16, 512, 15.6, 144, 2.10, 57],
    ["HP Victus 16", "HP", 22990000, 7, 4050, 16, 512, 16.1, 144, 2.30, 70],
    ["ASUS Vivobook 16", "ASUS", 15990000, 5, 2050, 16, 512, 16.0, 60, 1.88, 42],
    ["Lenovo IdeaPad Slim 5", "Lenovo", 17990000, 6, 0, 16, 512, 16.0, 60, 1.89, 57],
    ["Dell Inspiron 14", "Dell", 16990000, 5, 0, 16, 512, 14.0, 60, 1.54, 54],
    ["MacBook Air M3", "Apple", 24990000, 9, 0, 16, 512, 15.3, 60, 1.51, 66],
    ["Acer Swift Go 14", "Acer", 19990000, 7, 0, 16, 512, 14.0, 90, 1.32, 65],
    ["ASUS ROG Zephyrus G14", "ASUS", 39990000, 9, 4070, 32, 1000, 14.0, 120, 1.72, 73],
]

columns = [
    "Laptop", "Brand", "Price", "CPU", "GPU", "RAM", "SSD",
    "Screen", "Refresh", "Weight", "Battery"
]
df = pd.DataFrame(data, columns=columns)

# Approximate GPU score for normalization.
gpu_score = {0: 0, 2050: 45, 4050: 75, 4060: 90, 4070: 100}
df["GPUScore"] = df["GPU"].map(gpu_score)

# -----------------------------
# UI
# -----------------------------
st.title("💻 Hệ hỗ trợ quyết định lựa chọn Laptop")
st.caption("Mô hình mẫu sử dụng Weighted Sum Model (WSM)")

with st.sidebar:
    st.header("1. Nhu cầu người dùng")

    purpose = st.selectbox(
        "Mục đích sử dụng",
        ["Văn phòng / học tập", "Lập trình", "Gaming", "Đồ họa / AI", "Cân bằng"]
    )

    budget = st.slider(
        "Ngân sách tối đa (triệu VNĐ)",
        min_value=10, max_value=50, value=25, step=1
    ) * 1_000_000

    min_ram = st.selectbox("RAM tối thiểu", [8, 16, 32], index=1)
    min_refresh = st.selectbox("Tần số quét tối thiểu", [60, 90, 120, 144], index=0)

    st.header("2. Mức độ ưu tiên")
    st.write("Kéo thanh để thể hiện mức độ quan trọng.")

    w_price = st.slider("Giá", 1, 10, 8)
    w_cpu = st.slider("CPU", 1, 10, 7)
    w_gpu = st.slider("GPU", 1, 10, 8)
    w_ram = st.slider("RAM", 1, 10, 6)
    w_screen = st.slider("Màn hình", 1, 10, 5)
    w_weight = st.slider("Trọng lượng", 1, 10, 4)
    w_battery = st.slider("Pin", 1, 10, 5)

# -----------------------------
# Adjust weights by purpose
# -----------------------------
weights = {
    "Price": w_price,
    "CPU": w_cpu,
    "GPUScore": w_gpu,
    "RAM": w_ram,
    "Refresh": w_screen,
    "Weight": w_weight,
    "Battery": w_battery,
}

if purpose == "Gaming":
    weights["GPUScore"] += 3
    weights["Refresh"] += 2
elif purpose == "Lập trình":
    weights["CPU"] += 2
    weights["RAM"] += 2
    weights["Weight"] += 1
elif purpose == "Đồ họa / AI":
    weights["GPUScore"] += 4
    weights["RAM"] += 2
    weights["CPU"] += 2
elif purpose == "Văn phòng / học tập":
    weights["Price"] += 2
    weights["Weight"] += 2
    weights["Battery"] += 2

# -----------------------------
# Hard constraints
# -----------------------------
eligible = df[
    (df["Price"] <= budget) &
    (df["RAM"] >= min_ram) &
    (df["Refresh"] >= min_refresh)
].copy()

if eligible.empty:
    st.error("Không có laptop nào đáp ứng toàn bộ điều kiện. Hãy tăng ngân sách hoặc giảm yêu cầu.")
    st.stop()

# -----------------------------
# WSM normalization
# -----------------------------
def normalize_benefit(series):
    min_v, max_v = series.min(), series.max()
    if max_v == min_v:
        return pd.Series(1.0, index=series.index)
    return (series - min_v) / (max_v - min_v)

def normalize_cost(series):
    min_v, max_v = series.min(), series.max()
    if max_v == min_v:
        return pd.Series(1.0, index=series.index)
    return (max_v - series) / (max_v - min_v)

eligible["N_Price"] = normalize_cost(eligible["Price"])
eligible["N_CPU"] = normalize_benefit(eligible["CPU"])
eligible["N_GPU"] = normalize_benefit(eligible["GPUScore"])
eligible["N_RAM"] = normalize_benefit(eligible["RAM"])
eligible["N_Refresh"] = normalize_benefit(eligible["Refresh"])
eligible["N_Weight"] = normalize_cost(eligible["Weight"])
eligible["N_Battery"] = normalize_benefit(eligible["Battery"])

total_weight = sum(weights.values())

eligible["Score"] = (
    eligible["N_Price"] * weights["Price"] +
    eligible["N_CPU"] * weights["CPU"] +
    eligible["N_GPU"] * weights["GPUScore"] +
    eligible["N_RAM"] * weights["RAM"] +
    eligible["N_Refresh"] * weights["Refresh"] +
    eligible["N_Weight"] * weights["Weight"] +
    eligible["N_Battery"] * weights["Battery"]
) / total_weight * 100

eligible = eligible.sort_values("Score", ascending=False).reset_index(drop=True)

# -----------------------------
# Results
# -----------------------------
st.subheader("3. Kết quả đề xuất")

top = eligible.iloc[0]

col1, col2, col3 = st.columns(3)
col1.metric("🥇 Laptop đề xuất", top["Laptop"])
col2.metric("Điểm phù hợp", f'{top["Score"]:.1f}/100')
col3.metric("Giá", f'{top["Price"]/1_000_000:.1f} triệu')

st.success(
    f"**{top['Laptop']}** đang đứng đầu vì phù hợp nhất với trọng số và các yêu cầu bạn đã nhập."
)

st.subheader("Bảng xếp hạng")

display = eligible[[
    "Laptop", "Brand", "Price", "CPU", "GPU", "RAM",
    "SSD", "Screen", "Refresh", "Weight", "Battery", "Score"
]].copy()

display["Price"] = display["Price"].map(lambda x: f"{x/1_000_000:.1f} triệu")
display["Weight"] = display["Weight"].map(lambda x: f"{x:.2f} kg")
display["Score"] = display["Score"].map(lambda x: f"{x:.1f}")

st.dataframe(display, use_container_width=True, hide_index=True)

# -----------------------------
# Explanation
# -----------------------------
st.subheader("4. Giải thích quyết định")

explanation = {
    "Giá": weights["Price"],
    "CPU": weights["CPU"],
    "GPU": weights["GPUScore"],
    "RAM": weights["RAM"],
    "Màn hình": weights["Refresh"],
    "Trọng lượng": weights["Weight"],
    "Pin": weights["Battery"],
}

explain_df = pd.DataFrame(
    {"Tiêu chí": explanation.keys(), "Trọng số": explanation.values()}
).sort_values("Trọng số", ascending=False)

st.bar_chart(explain_df.set_index("Tiêu chí"))

st.write("### Vì sao laptop đứng đầu?")
reasons = []

if top["Price"] <= budget:
    reasons.append("✓ Nằm trong ngân sách")
if top["RAM"] >= min_ram:
    reasons.append(f"✓ RAM đạt yêu cầu ({top['RAM']} GB)")
if top["Refresh"] >= min_refresh:
    reasons.append(f"✓ Tần số quét đạt yêu cầu ({top['Refresh']} Hz)")
if top["GPUScore"] >= 75:
    reasons.append("✓ GPU phù hợp cho tác vụ đồ họa / gaming")
if top["Weight"] <= 2.0:
    reasons.append("✓ Khối lượng tương đối nhẹ")
if top["Battery"] >= 60:
    reasons.append("✓ Dung lượng pin tốt")

for reason in reasons:
    st.write(reason)

st.caption(
    "Lưu ý: Đây là mô hình DSS minh họa. Điểm CPU/GPU và dữ liệu laptop là dữ liệu mẫu, "
    "cần thay bằng dữ liệu thực tế khi làm đồ án."
)

# -----------------------------
# Data editor
# -----------------------------
with st.expander("🔧 Xem / chỉnh sửa dữ liệu laptop"):
    edited = st.data_editor(
        df[columns],
        use_container_width=True,
        hide_index=True,
        num_rows="dynamic"
    )
    st.info("Phiên bản mẫu chưa tự động lưu dữ liệu chỉnh sửa vào database.")
