import numpy as np


def ahp_weights(matrix):
    matrix = np.array(matrix, dtype=float)

    # Eigenvalues + eigenvectors
    eigenvalues, eigenvectors = np.linalg.eig(matrix)

    max_index = np.argmax(eigenvalues.real)

    max_eigenvalue = eigenvalues[max_index].real
    weights = eigenvectors[:, max_index].real

    # Make positive
    weights = np.abs(weights)

    # Normalize
    weights = weights / weights.sum()

    # Consistency Index
    n = len(matrix)

    CI = (max_eigenvalue - n) / (n - 1)

    RI_table = {
        1: 0,
        2: 0,
        3: 0.58,
        4: 0.90,
        5: 1.12,
        6: 1.24,
        7: 1.32,
        8: 1.41,
        9: 1.45,
        10: 1.49
    }

    RI = RI_table[n]

    CR = CI / RI if RI != 0 else 0

    return weights, CR