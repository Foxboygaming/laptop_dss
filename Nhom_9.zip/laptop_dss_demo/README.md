# Laptop DSS
Hệ hỗ trợ quyết định lựa chọn laptop bằng Weighted Sum Model (WSM).

## Chạy
```bash
pip install -r requirements.txt
streamlit run app.py
```

Mở http://localhost:8501 trên trình duyệt.
