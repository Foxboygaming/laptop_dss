import numpy as np
import pandas as pd


def topsis(df, criteria, weights, benefit):
    matrix = df[criteria].astype(float).values

    # 1. Normalize
    denominator = np.sqrt((matrix ** 2).sum(axis=0))
    normalized = matrix / denominator

    # 2. Weighted normalized matrix
    weighted = normalized * np.array(weights)

    # 3. Ideal / anti-ideal
    ideal = []
    anti_ideal = []

    for j, is_benefit in enumerate(benefit):

        if is_benefit:
            ideal.append(weighted[:, j].max())
            anti_ideal.append(weighted[:, j].min())

        else:
            ideal.append(weighted[:, j].min())
            anti_ideal.append(weighted[:, j].max())

    ideal = np.array(ideal)
    anti_ideal = np.array(anti_ideal)

    # 4. Distances
    distance_positive = np.sqrt(
        ((weighted - ideal) ** 2).sum(axis=1)
    )

    distance_negative = np.sqrt(
        ((weighted - anti_ideal) ** 2).sum(axis=1)
    )

    # 5. Closeness coefficient
    score = distance_negative / (
        distance_positive + distance_negative
    )

    result = df.copy()

    result["TOPSIS_Score"] = score
    result["Rank"] = (
        result["TOPSIS_Score"]
        .rank(ascending=False)
        .astype(int)
    )

    return result.sort_values(
        "TOPSIS_Score",
        ascending=False
    )